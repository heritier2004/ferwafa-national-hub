@echo off
setlocal enabledelayedexpansion

echo ==================================================
echo   FERWAFA National Football Intelligence Hub
echo        AI PITCH MACHINE - INSTALLER
echo ==================================================

:: 1. Check for Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Please install Python 3.10+ and add it to PATH.
    pause
    exit /b
)

:: 2. Create Virtual Environment
if not exist .venv (
    echo [*] Creating isolated intelligence environment...
    python -m venv .venv
)

:: 3. Update Pip & Install Core Requirements
echo [*] Synchronizing AI dependencies...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install torch torchvision torchaudio psutil ultralytics opencv-python easyocr requests winshell pypiwin32

:: 4. Run Hardware Diagnostic
echo [*] Running Hardware Authorization...
python check_hardware.py

:: 5. Create Desktop Shortcut
echo [*] Generating Home Screen Launcher...
python create_desktop_icon.py

:: 6. Launch Setup Wizard
echo [*] Launching Intelligence Configuration...
python setup_wizard.py

echo ==================================================
echo   INSTALLATION COMPLETE. USE DESKTOP ICON NEXT.
echo ==================================================
pause
